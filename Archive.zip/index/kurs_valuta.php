<div class="row u-bg--white u-box-shadow u-pad-bottom--20 u-margin-bottom--30 u-pad-top--20">
<div class="container">

		
			
			<div class="eight columns alpha">
				<article class="icon-box" style="padding-left:30px; text-align: center;">
					
					<h3 class="c-new-title-content">Kurs <span>Valuta Asing</span></h3>
					 <iframe id="kurs_rupiah" name="kurs_rupiah" width="306px" height="230px" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" scrolling="no" src="http://widget.kontan.co.id/v2/kursrupiah"></iframe>
				</article>
			</div>
			


			<div class="eight columns alphan">
				<article class="icon-box" style="padding-left:30px; text-align: center;">
					<h3 class="c-new-title-content">Statistik<span> Pengunjung</span></h3>
					<script type="text/javascript" src="http://widget.supercounters.com/flag.js"></script><script type="text/javascript">sc_flag(670731,"FFFFFF","000000","cccccc",2,20,0,0)</script><br><noscript><a href="http://www.supercounters.com/">Flag Counter</a></noscript>
				</article>
			</div>
		
		

	</div>
</div>

