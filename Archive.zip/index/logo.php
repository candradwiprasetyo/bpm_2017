<div class="c-header">
	<div class="container floated">
		<div class="ten columns">
			<div class="logo-left">
				<img src="images/new_logo.png">
			</div>
			<div class="title-left">
				<div class="c-title">
					DPM PTSP Provinsi Jawa Timur
				</div>
				<div class="c-subtitle">
					Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Provinsi Jawa Timur
				</div>
			</div>
		</div>
		<div class="six columns">
			<div class="logo-right">
				<?php include 'flag.php'; ?>
			</div>
		</div>
	</div>
</div>