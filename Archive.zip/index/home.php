

<?php include 'slider.php'; ?>

<?php include 'profile.php'; ?>

<?php include 'kinerja_investasi.php'; ?>

<?php include 'berita.php'; ?>


<!-- 960 Container 
<div class="container floated">
	<div class="blank floated">

		<div class="icon-box-container">
			
			<div class="one-third column">
				<article class="icon-box">
					
					<h3>Kurs <span>Valuta Asing</span></h3>
					 <iframe id="kurs_rupiah" name="kurs_rupiah" width="306px" height="230px" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" scrolling="no" src="http://widget.kontan.co.id/v2/kursrupiah"></iframe>
				</article>
			</div>
			
			<div class="one-third column">
				<article class="icon-box" style="padding-left:20px;">
					<h3>Jadwal <span>Penerbangan</span></h3>
					<div id="snippet_searchpanel" style="width: auto; height:auto;"></div>
				</article>
			</div>

			<div class="one-third column">
				<article class="icon-box" style="padding-left:30px;">
					<h3>Statistik<span> Pengunjung</span></h3>
					<script type="text/javascript" src="http://widget.supercounters.com/flag.js"></script><script type="text/javascript">sc_flag(670731,"FFFFFF","000000","cccccc",2,20,0,0)</script><br><noscript><a href="http://www.supercounters.com/">Flag Counter</a></noscript>
				</article>
			</div>
		</div>
		

	</div>
</div>
<!-- 960 Container / End -->
