<!-- Footer Bottom / Start  -->
<footer id="footer-bottom">

	<!-- 960 Container -->
	<div class="container">

		<!-- Copyrights -->
		<div class="eight columns">
			<div class="copyright">
				© Copyright 2017 by <a href="#">DPM PTSP Jawa Timur</a>. All Rights Reserved.
			</div>
		</div>

		<!-- Menu -->
		<div class="eight columns">
			<nav id="sub-menu">
				<ul>
					<li><a href="index.php?page=content_utama&id_menu=41">FAQ's</a></li>
					<li><a href="index.php?page=contact_question">Kirim pertanyaan</a></li>
					<li><a href="index.php?page=content_utama&id_menu=42">Contact</a></li>
				</ul>
			</nav>
		</div>

	</div>
	<!-- 960 Container / End -->

</footer>
<!-- Footer Bottom / End -->