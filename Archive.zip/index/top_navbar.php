<div class="top-navbar">
  	<div class="container floated">
    	<div class="top-navbar__content">
        <div class="container">
      		<div class="navbar">
	        	<div class="item">
	        		<i class="halflings white map-marker"></i> Jalan Johar No.17 Surabaya
	        	</div>
	        	<div class="item">
	        		<i class="halflings white phone"></i> 031-99092900
	        	</div>
	        	<div class="item">
	        		<i class="halflings white envelope"></i> dpmptsp@jatimprov.go.id
	        	</div>
      		</div>
    	
    		<div class="navbar-right">
    			<input type="search" placeholder="Cari disini ...">
    		</div>
    	</div>
  	</div>  
  </div>
</div>