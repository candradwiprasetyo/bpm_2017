

<?php include 'slider.php'; ?>

<?php include 'profile_new.php'; ?>

<?php include 'pejabat_pengelola_informasi.php'; ?>

<?php include 'agenda_kegiatan.php'; ?>

<?php include 'kinerja_investasi.php'; ?>

<?php include 'berita.php'; ?>

<?php include 'peraturan_terkait.php'; ?>

<?php include 'kurs_valuta.php'; ?>